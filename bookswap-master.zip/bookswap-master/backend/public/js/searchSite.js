
// DROPDOWN BOX

let dropdownButtonSearchOption = document.querySelector('.dropdown-toggle-search-option')
if (dropdownButtonSearchOption) {
	dropdownButtonSearchOption.addEventListener('click', searchOptions)
}

function dropdownMenu(menu) {
	if (menu.style.display == "none" || !(menu.style.display)) {
		menu.style.display = "block"
	} else {
		menu.style.display = "none"
	}
}
function searchOptions() {
	let x = document.querySelector('.dropdown-menu-search-option')
	dropdownMenu(x)
}


function fetch() {
	let get = document.getElementById("get").value;
	document.getElementById("put").innerHTML = `Max ${get} km away from you`;
}

