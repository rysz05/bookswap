var doubleColors = [
	['#ffff66', '#ffff4d'], ['#ffe033', '#ffdd1a'], ['#ffc966', '#ffc14d'], ['#dac1a0', '#cead82'], ['#ff974d', '#ff8833'], ['#ff8080', '#ff6666'], ['#ffb8db', '#ff9ecf'], ['#ff80ff', '#ff66ff'], ['#c880ff', '#bd66ff'], ['#8080ff', '#6666ff'], ['#DD98FA', '#eec9f4'], ['#33FF92', '#2DDF80']]

  var x, y, i;
  x = document.querySelectorAll("#rect4660")
  y = document.querySelectorAll("#rect4550")
  z = document.querySelectorAll("#svg8")

for (i=0; i< x.length; i++) {

	var rand = doubleColors[Math.floor(Math.random() * doubleColors.length)];
	var color1 = rand[0]
	var color2 = rand[1]

	x[i].style.fill = color1;
	y[i].style.fill = color2
    x[i].onclick = changeColor;
    y[i].onclick = changeColor;

}

function changeColor(e) {

    var rand = doubleColors[Math.floor(Math.random() * doubleColors.length)];

 	e.target.style.fill = rand[1]

}
// NOT WORKING FOR NOW
