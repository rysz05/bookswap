
let condValue = document.querySelectorAll(".book_condition_value");
let condImg= document.querySelectorAll(".book_condition_pic");

if (condValue && condImg) {
	for (let i = 0; i < condValue.length; i++) {

		for (let j = 0; j < condImg.length; j++) {


			if (condImg[j].classList.item(1) == condValue[i].classList.item(1)) {

				if (condValue[i].value == "good") {
					condImg[j].src ="../pics/rysunek-good.svg";}
				else if (condValue[i].value == "medium") {
					condImg[j].src = "../pics/rysunek-medium.svg";}
				else if (condValue[i].value == "bad") {
					condImg[j].src = "../pics/rysunek-bad.svg";}
			}
	}
	}
}
