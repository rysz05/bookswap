test('Sample Test', () => {
		expect(true).toBe(true);

		if (process.env.NODE_ENV=="test") {
			console.log(`I am in a ${process.env.NODE_ENV} environment`)
		}
		if (process.env.NODE_ENV=="dev") {
			console.log(`I am in a ${process.env.NODE_ENV} environment`)
		}
	})
