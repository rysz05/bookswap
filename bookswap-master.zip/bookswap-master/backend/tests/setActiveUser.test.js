const res = require("../modules/db.js")

describe.only('sets the active user', () => {
	let data = [
		{
	    id: 1,
	    text: 'Hi',
	    user: '6',
	    chat_id: 1
	  	},
		{
	    id: 2,
	    text: 'Hello',
	    user: '6',
	    chat_id: 1
	  	},
		{
	    id: 3,
	    text: 'How are you?',
	    user: '6',
	    chat_id: 1
	  	}
	]
  it('should give an object', () => {
  	//let x =
    expect(typeof res.setActiveUser(data, 6)).toBe('object');
  });
  /*it('should set active user', () => {
  	let comp = [
		{
	    id: 1,
	    text: 'Hi',
	    user: '6',
	    chat_id: 1,
	    activeUser: true
	  	},
		{
	    id: 2,
	    text: 'Hello',
	    user: '7',
	    chat_id: 1
	  	},
		{
	    id: 3,
	    text: 'How are you?',
	    user: '7',
	    chat_id: 1
	  	}
	]
    expect(comp).toEqual(res.setActiveUser(data, 6));
  });*/
});
