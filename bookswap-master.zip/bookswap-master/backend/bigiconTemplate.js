
<div class="book-card book" id={%ID%}>
  <svg
    xmlns:dc="http://purl.org/dc/elements/1.1/"
    xmlns:cc="http://creativecommons.org/ns#"
    xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
    xmlns:svg="http://www.w3.org/2000/svg"
    xmlns="http://www.w3.org/2000/svg"
    xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
    xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
    width="198px"
    height="240px"
    viewBox="0 0 220 260"
    version="1.1"
    id="svg8"
    inkscape:version="1.0.1 (3bc2e813f5, 2020-09-07)"
    sodipodi:docname="rysunek.svg"
  >
    <defs id="defs2" />
    <sodipodi:namedview
      id="base"
      pagecolor="#ffffff"
      bordercolor="#666666"
      borderopacity="1.0"
      inkscape:pageopacity="0.0"
      inkscape:pageshadow="2"
      inkscape:zoom="0.48984232"
      inkscape:cx="761.08337"
      inkscape:cy="598.40853"
      inkscape:document-units="mm"
      inkscape:current-layer="layer1"
      inkscape:document-rotation="0"
      showgrid="false"
      inkscape:snap-grids="true"
      inkscape:snap-center="false"
      inkscape:snap-object-midpoints="false"
      inkscape:snap-smooth-nodes="false"
      inkscape:snap-intersection-paths="false"
      inkscape:object-paths="false"
      inkscape:window-width="1920"
      inkscape:window-height="1051"
      inkscape:window-x="-9"
      inkscape:window-y="-9"
      inkscape:window-maximized="1"
    />
    <metadata id="metadata5">
      <rdf:RDF>
        <cc:Work rdf:about="">
          <dc:format>image/svg+xml</dc:format>
          <dc:type rdf:resource="http://purl.org/dc/dcmitype/StillImage" />
          <dc:title></dc:title>
        </cc:Work>
      </rdf:RDF>
    </metadata>
    <g inkscape:label="Warstwa 1" inkscape:groupmode="layer" id="layer1">
      <path
        style="fill:#b3b3b3;fill-opacity:1;stroke:none;stroke-width:0.264583"
        id="path12057"
        sodipodi:type="arc"
        sodipodi:cx="231.65175"
        sodipodi:cy="137.5293"
        sodipodi:rx="3.2978508"
        sodipodi:ry="0.26739332"
        sodipodi:start="0.088600069"
        sodipodi:end="0.98317887"
        sodipodi:arc-type="slice"
        d="m 234.93666,137.55296 a 3.2978508,0.26739332 0 0 1 -1.45665,0.19888 l -1.82826,-0.22254 z"
      />
      <g
        id="g16193"
        transform="matrix(2.3702939,0,0,2.5031912,-209.96425,-91.307698)"
      >
        <rect
          style="fill:#00dcff;fill-opacity:1;fill-rule:evenodd;stroke-width:0.291492"
          id="rect4550"
          width="86.205666"
          height="102.34667"
          x="89.896408"
          y="37.833092"
          ry="9.5934687"
          transform="matrix(0.99999957,9.2598648e-4,-0.00102101,0.99999948,0,0)"
        />
        <path
          id="rect4660"
          style="fill:#59beff;fill-opacity:1;stroke:none;stroke-width:0.264583"
          d="m 99.492251,37.925433 c -5.31478,-0.0049 -9.59761,4.269647 -9.60303,9.584428 l -0.0853,83.159779 c -0.005,5.31478 4.26913,9.59708 9.58391,9.602 l 67.018649,0.062 c 5.31478,0.005 9.5976,-4.26965 9.60302,-9.58443 l 0.003,-2.96829 H 114.0381 V 37.938869 Z"
        />
        <path
          style="fill:#f2f2f2;fill-opacity:1;stroke:none;stroke-width:0.240607"
          d="m 102.92005,120.84585 h 66.74473 c 3.59655,0 6.55039,1.38323 6.40284,4.97675 l -0.0891,2.17082 c -0.035,0.85217 -1.9891,3.59655 -3.90701,5.25272 -1.55556,1.34327 -5.92123,2.56279 -6.77414,2.56279 l -62.37728,-0.0891 c -3.596559,0 -6.491989,-2.89543 -6.491989,-6.49198 v -1.88999 c 0,-3.59656 2.89543,-6.49198 6.491979,-6.49198 z"
          id="path12099"
          sodipodi:nodetypes="csscsccsscc"
        />
        <path
          style="fill:#f2f2f2;fill-opacity:1;stroke:none;stroke-width:0.240607"
          d="m 176.01253,127.78092 c -4.90237,-1.22732 -15.8376,-5.82981 -11.69133,-6.86445 0,0 1.1399,-0.1749 2.53817,-0.46905 1.39828,-0.29415 3.05494,-0.70754 4.0885,-1.18453 1.5136,-0.69852 2.91705,-1.67231 3.88056,-3.03267 0.81056,-1.14442 1.17047,-4.04108 1.17047,-4.04108 z"
          id="path12055"
          sodipodi:nodetypes="ccssscc"
        />
        <path
          style="fill:#b3b3b3;fill-opacity:1;stroke:none;stroke-width:0.157819"
          d="m 99.807571,124.91878 69.678029,-0.2521 c 3.74929,-0.0136 7.01231,-5.13015 6.31342,-0.2465 l -0.8813,1.3371 c -0.0984,0.14937 -0.58481,0.71377 -1.20718,1.38399 -0.62236,0.67021 -1.47093,1.25597 -2.373,1.79224 -1.62165,0.96403 -3.6432,2.0976 -4.53233,2.0976 l -66.997599,0.0265 c -3.74932,0 -3.35249,-0.55937 -3.42441,-1.29774 -0.0719,-0.73837 -0.17148,-1.76046 -0.17148,-1.76046 0.61713,-2.37563 -0.15343,-3.08037 3.59588,-3.08037 z"
          id="path12103"
          sodipodi:nodetypes="ccccsscczccc"
        />
        <path
          style="fill:#b3b3b3;fill-opacity:1;stroke:none;stroke-width:0.159861"
          d="m 175.83025,124.48321 c -5.23107,3.02191 -20.35921,1.11596 -9.17523,0.20811 1.49563,-0.1214 2.42354,-0.49944 3.55363,-0.96063 1.43801,-0.58685 2.95277,-1.20528 4.03325,-2.26896 0.90029,-0.88629 1.84613,-3.23521 1.84613,-3.23521 z"
          id="path12055-1"
          sodipodi:nodetypes="cssscc"
        />
      </g>
    </g>
  </svg>
  <div class="book-inside">
    <div class="book-title">{{books.title}}</div>
    <div class="book-author">{{books.author}}</div>
    <div class="button-box">
      <button
        class="button2 buttons hidden"g
        onclick="document.getElementById('modal-{%ID%}').style.display='block'">
        <i class="far fa-window-close"></i>
      </button>
      <button class="button2 buttons hidden edit-btt">
        <i class="fas fa-edit"></i>
      </button>
      <div id="modal-{%ID%}" class="sadmodal modal1" style="display: none">
        <div class="sadmodal-content">
          <div class="sadmodal-box">
            <span
              onclick="document.getElementById('modal-{%ID%}').style.display='none'"
              class="sadmodal-exit-button">
              <i class="far fa-window-close"></i>
            </span>
            <p>Do you want to take the book off the bookshelf?</p>
            <button class="yes-btt">
              Yes
            </button>
          </div>
        </div>
      </div>
      <div class="book-quote-box">
        <p class="quote-txt">Edit your quote: </p>
        <textarea disabled placeholder="{%QUOTE%}"></textarea>
      </div>
    </div>
  </div>
</div>

